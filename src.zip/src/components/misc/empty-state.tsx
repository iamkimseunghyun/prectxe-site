export function EmptyState() {
  return (
    <div className="py-12 text-center">
      <p className="text-gray-600">No projects found.</p>
    </div>
  );
}
