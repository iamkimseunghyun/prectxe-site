// types/index.ts
export interface Project {
  id: string;
  title: string;
  description: string;
  content: string;
  year: number;
  category: string;
  images: {
    id: string;
    url: string;
    alt: string | null;
  }[];
  createdAt: Date;
  updatedAt: Date;
}
