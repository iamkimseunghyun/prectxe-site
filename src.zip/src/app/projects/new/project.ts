// app/actions/project.ts
'use server';

import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';
import { projectSchema } from '@/lib/validations/project';
import { redirect } from 'next/navigation';

export async function createProject(formData: FormData) {
  // FormData를 객체로 변환
  const rawData = {
    title: formData.get('title'),
    year: Number(formData.get('year')),
    category: formData.get('category'),
    description: formData.get('description'),
    content: formData.get('content'),
    mainImageUrl: formData.get('mainImageUrl'),
    startDate: formData.get('startDate'),
    endDate: formData.get('endDate'),
  };

  // Zod로 유효성 검사
  const validatedData = projectSchema.safeParse(rawData);

  if (!validatedData.success) {
    // 타입 안전한 에러 처리
    return validatedData.error.flatten();
  } else {
    // 데이터베이스에 저장
    const project = await prisma.project.create({
      data: {
        title: validatedData.data.title,
        description: validatedData.data.description,
        content: validatedData.data.content,
        year: validatedData.data.year,
        category: validatedData.data.category,
        mainImageUrl: validatedData.data.mainImageUrl,
        startDate: new Date(validatedData.data.startDate as string),
        endDate: new Date(validatedData.data.endDate as string),
      },
    });
    revalidatePath('/projects');
    revalidatePath('/');
    redirect(`/projects/detail/${project.id}`);
  }
}

export async function getUploadedProductImageURL() {
  const response = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${process.env.CLOUDFLARE_IMAGE_STREAM_API_ACCOUNT_ID}/images/v2/direct_upload`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.CLOUDFLARE_IMAGE_STREAM_API_TOKEN}`,
      },
    }
  );

  const data = await response.json();
  return data;
}
