'use client';

import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { ProjectFormData, projectSchema } from '@/lib/validations/project';

import { useRouter } from 'next/navigation';
import React, { ChangeEvent, useState } from 'react';
import { ImagePlus } from 'lucide-react';
import { formatDate } from '@/lib/utils';
import {
  createProject,
  getUploadedProductImageURL,
} from '@/app/projects/new/project';

const categories = [
  { value: 'exhibition', label: '전시' },
  { value: 'performance', label: '공연' },
  { value: 'festival', label: '페스티벌' },
  { value: 'workshop', label: '워크숍' },
] as const;

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const ALLOWED_FILE_TYPES = [
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
  'image/gif',
];

const Page = () => {
  const router = useRouter();
  const [preview, setPreview] = useState('');
  const [fileError, setFileError] = useState('');
  const [uploadURL, setUploadURL] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<ProjectFormData>({
    resolver: zodResolver(projectSchema),
    defaultValues: {
      title: '',
      year: new Date().getFullYear(),
      category: undefined,
      description: '',
      content: '',
      mainImageUrl: '',
      startDate: formatDate(new Date()),
      endDate: formatDate(new Date()),
    },
  });

  const onImageChange = async (event: ChangeEvent<HTMLInputElement>) => {
    const {
      target: { files },
    } = event;
    setFileError('');
    if (!files || files.length === 0) {
      console.log('No files selected');
      return;
    }
    const localFile = files[0];

    // 파일 타입 검증
    if (!ALLOWED_FILE_TYPES.includes(localFile.type)) {
      setFileError(
        '지원되지 않는 이미지 형식입니다. JPG, PNG, GIF, WEBP만 가능합니다.'
      );
      return;
    }

    // 파일 크기 검증
    if (localFile.size > MAX_FILE_SIZE) {
      setFileError('파일 크기는 5MB를 초과할 수 없습니다.');
      return;
    }

    const previewURL = URL.createObjectURL(localFile);
    setPreview(previewURL);
    setImageFile(localFile);
    const { success, result } = await getUploadedProductImageURL();
    if (success) {
      const { id, uploadURL } = result;
      setUploadURL(uploadURL);
      setValue(
        'mainImageUrl',
        `https://imagedelivery.net/UYdYeWsHCBBURfLH8Q-Ggw/${id}`
      );
    }
  };

  const onSubmit = handleSubmit(async (data: ProjectFormData) => {
    if (!imageFile) {
      return;
    }
    // upload image to cloudflare
    const cloudFlareForm = new FormData();
    cloudFlareForm.append('file', imageFile);
    const response = await fetch(uploadURL, {
      method: 'POST',
      body: cloudFlareForm,
    });
    if (response.status !== 200) {
      return;
    }

    const formData = new FormData();
    formData.append('title', data.title);
    formData.append('year', data.year + '');
    formData.append('category', data.category);
    formData.append('description', data.description);
    formData.append('content', data.content);
    formData.append('mainImageUrl', data.mainImageUrl);
    formData.append('startDate', data.startDate);
    formData.append('endDate', data.endDate);
    // call upload product.
    await createProject(formData);
  });

  const onValid = async () => {
    await onSubmit();
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mx-auto max-w-3xl">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">프로젝트 등록</CardTitle>
            <CardDescription>
              새로운 프로젝트의 정보를 입력해주세요.
            </CardDescription>
          </CardHeader>

          <form action={onValid}>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-center space-y-6">
                <label
                  htmlFor="mainImageUrl"
                  className="flex aspect-square h-[50%] w-[50%] cursor-pointer flex-col items-center justify-center rounded-md border-2 border-dashed border-neutral-300 bg-cover bg-center text-neutral-300"
                  style={{ backgroundImage: `url(${preview})` }}
                >
                  {preview === '' ? (
                    <>
                      <ImagePlus className="size-8" />
                      <div className="text-sm text-neutral-400">
                        <p className="mt-2">사진을 추가해주세요.</p>
                        {/* {state?.fieldErrors.photo} */}
                        {errors.mainImageUrl?.message}
                      </div>
                    </>
                  ) : null}
                </label>
                <input
                  type="file"
                  id="mainImageUrl"
                  name="mainImageUrl"
                  accept="image/*"
                  onChange={onImageChange}
                  className="hidden"
                />
                {fileError && (
                  <div className="mt-2 text-sm text-red-500">{fileError}</div>
                )}
              </div>
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">제목</label>
                  <Input
                    placeholder="프로젝트 제목을 입력하세요"
                    {...register('title')}
                  />
                  {errors.title && (
                    <p id="title-error" className="text-sm text-destructive">
                      {errors.title.message}
                    </p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">연도</label>
                    <Input
                      type="number"
                      defaultValue={new Date().getFullYear()}
                      min={2018}
                      max={new Date().getFullYear()}
                      {...register('year', { valueAsNumber: true })}
                    />
                    {errors.year && (
                      <p id="year-error" className="text-sm text-destructive">
                        {errors.year.message}
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">카테고리</label>
                    <Select
                      onValueChange={(
                        value:
                          | 'exhibition'
                          | 'performance'
                          | 'festival'
                          | 'workshop'
                      ) => setValue('category', value)}
                      value={watch('category')}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="카테고리 선택" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem
                            key={category.value}
                            value={category.value}
                          >
                            {category.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.category && (
                      <p
                        id="category-error"
                        className="text-sm text-destructive"
                      >
                        {errors.category?.message}
                      </p>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">시작일</label>
                    <Input
                      type="date"
                      {...register('startDate')}
                      defaultValue={formatDate(new Date())}
                    />
                    {errors.startDate && (
                      <p
                        id="startDate-error"
                        className="text-sm text-destructive"
                      >
                        {errors.startDate?.message}
                      </p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">종료일</label>
                    <Input
                      type="date"
                      {...register('endDate')}
                      defaultValue={formatDate(new Date())}
                    />
                    {errors.endDate && (
                      <p
                        id="endDate-error"
                        className="text-sm text-destructive"
                      >
                        {errors.endDate?.message}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">설명</label>
                <Textarea
                  {...register('description')}
                  placeholder="프로젝트에 대한 간단한 설명을 입력하세요"
                  rows={3}
                />
                {errors?.description && (
                  <p
                    id="description-error"
                    className="text-sm text-destructive"
                  >
                    {errors.description?.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">내용</label>
                <Textarea
                  {...register('content')}
                  placeholder="프로젝트의 상세 내용을 입력하세요"
                  rows={8}
                />
                {errors?.content && (
                  <p id="content-error" className="text-sm text-destructive">
                    {errors.content?.message}
                  </p>
                )}
              </div>
            </CardContent>

            <CardFooter className="flex justify-end gap-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => router.back()}
              >
                취소
              </Button>
              <Button type="submit">등록하기</Button>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default Page;
