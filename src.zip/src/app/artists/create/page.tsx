'use client';

import { useState } from 'react';

import { useForm } from 'react-hook-form';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { zodResolver } from '@hookform/resolvers/zod';
import { createArtist } from '@/app/artists/create/actions';
import { toast } from '@/hooks/use-toast';

// 아티스트 등록 폼 스키마 정의
const artistFormSchema = z.object({
  name: z.string().min(2, {
    message: '이름은 2글자 이상이어야 합니다.',
  }),
  photo: z.string().url({
    message: '올바른 URL을 입력해주세요.',
  }),
  birth: z.string(),
  nationality: z.string().min(2, {
    message: '국적을 입력해주세요.',
  }),
  city: z.string().min(2, {
    message: '도시를 입력해주세요.',
  }),
  country: z.string().min(2, {
    message: '국가를 입력해주세요.',
  }),
  email: z.string().email({
    message: '올바른 이메일 주소를 입력해주세요.',
  }),
  homepage: z.string().url({
    message: '올바른 URL을 입력해주세요.',
  }),
  biography: z.string().min(10, {
    message: '약력은 10자 이상 입력해주세요.',
  }),
  cv: z.string().min(10, {
    message: '이력서는 10자 이상 입력해주세요.',
  }),
});

type ArtistFormValues = z.infer<typeof artistFormSchema>;

const Page = () => {
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<ArtistFormValues>({
    resolver: zodResolver(artistFormSchema),
    defaultValues: {
      name: '',
      photo: '',
      birth: '',
      nationality: '',
      city: '',
      country: '',
      email: '',
      homepage: '',
      biography: '',
      cv: '',
    },
  });

  async function onSubmit(data: ArtistFormValues) {
    setIsLoading(true);
    try {
      const result = await createArtist(data);

      if (!result.success) {
        toast({
          title: '등록 실패',
          description: '콘솔 에러 메세지를 확인하세요.',
        });
      }
    } catch (error) {
      if ((error as Error).message.includes('NEXT_REDIRECT')) {
        // 리디렉션은 에러가 아니므로 무시합니다
        return;
      }
      toast({
        title: '아티스트 등록 중 오류가 발생했습니다.',
        description: '에러 메세지를 확인해요',
      });
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card>
        <CardHeader>
          <CardTitle>아티스트 등록</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>이름</FormLabel>
                      <FormControl>
                        <Input placeholder="아티스트 이름" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="photo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>프로필 사진 URL</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="https://example.com/photo.jpg"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="birth"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>생년월일</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="nationality"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>국적</FormLabel>
                        <FormControl>
                          <Input placeholder="국적" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="country"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>국가</FormLabel>
                        <FormControl>
                          <Input placeholder="국가" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>도시</FormLabel>
                      <FormControl>
                        <Input placeholder="도시" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>이메일</FormLabel>
                      <FormControl>
                        <Input placeholder="email@example.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="homepage"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>홈페이지</FormLabel>
                      <FormControl>
                        <Input placeholder="https://example.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="biography"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>약력</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="아티스트의 약력을 입력해주세요."
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="cv"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>이력서</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="아티스트의 이력서를 입력해주세요."
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => window.history.back()}
                  >
                    취소
                  </Button>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading ? '등록 중...' : '아티스트 등록'}
                  </Button>
                </div>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
};

export default Page;
