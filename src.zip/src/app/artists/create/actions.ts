// app/artists/actions.ts
'use server';

import { PrismaClient } from '@prisma/client';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';

const prisma = new PrismaClient();

export async function createArtist(formData: {
  name: string;
  photo: string;
  birth: string;
  nationality: string;
  city: string;
  country: string;
  email: string;
  homepage: string;
  biography: string;
  cv: string;
}) {
  try {
    const artist = await prisma.artist.create({
      data: {
        ...formData,
        birth: new Date(formData.birth),
      },
    });

    revalidatePath('/artists');
    redirect(`/artists/detail/${artist.id}`);
  } catch (error) {
    console.error('Error creating artist:', error);
    return { success: false, error: '아티스트 등록에 실패했습니다.' };
  }
}
