const Page = () => {
  return <div>artist detail</div>;
};

export default Page;
