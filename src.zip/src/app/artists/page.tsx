'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PlusCircle, Search, Mail, MapPin, Globe } from 'lucide-react';

const ArtistsList = () => {
  // Sample data - replace with actual data fetching
  const [artists] = useState([
    {
      id: '1',
      name: 'John Doe',
      nationality: 'American',
      city: 'New York',
      email: 'john@example.com',
      photo:
        'http://localhost:3000/_next/image?url=https%3A%2F%2Fimagedelivery.net%2FUYdYeWsHCBBURfLH8Q-Ggw%2Fff47971e-3c2e-4f00-253b-95a5c6569f00%2Fpublic&w=1920&q=75',
      homepage: 'https://johndoe.com',
      createdAt: '2024-01-15',
    },
    {
      id: '2',
      name: 'Jane Smith',
      nationality: 'British',
      city: 'London',
      email: 'jane@example.com',
      photo:
        'http://localhost:3000/_next/image?url=https%3A%2F%2Fimagedelivery.net%2FUYdYeWsHCBBURfLH8Q-Ggw%2Fff47971e-3c2e-4f00-253b-95a5c6569f00%2Fpublic&w=1920&q=75',
      homepage: 'https://janesmith.com',
      createdAt: '2024-01-16',
    },
    // Add more sample data as needed
  ]);

  const [searchTerm, setSearchTerm] = useState('');

  // Search function
  const filteredArtists = artists.filter((artist) =>
    Object.values(artist).some((value) =>
      value.toString().toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-3xl font-bold">Artists</h1>
          <Button onClick={() => (window.location.href = '/artists/new')}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Artist
          </Button>
        </div>

        <div className="relative">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Search artists..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-md pl-8"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filteredArtists.map((artist) => (
          <Card
            key={artist.id}
            className="overflow-hidden transition-shadow hover:shadow-lg"
          >
            <div className="relative aspect-square">
              <img
                src={artist.photo}
                alt={artist.name}
                className="h-full w-full object-cover"
              />
            </div>
            <CardContent className="pt-6">
              <h3 className="mb-2 text-xl font-semibold">{artist.name}</h3>
              <div className="space-y-2 text-sm text-gray-600">
                <p className="flex items-center">
                  <Globe className="mr-2 h-4 w-4" />
                  {artist.nationality}
                </p>
                <p className="flex items-center">
                  <MapPin className="mr-2 h-4 w-4" />
                  {artist.city}
                </p>
                <p className="flex items-center">
                  <Mail className="mr-2 h-4 w-4" />
                  {artist.email}
                </p>
              </div>
              <div className="mt-4 flex items-center justify-between border-t pt-4">
                <span className="text-sm text-gray-500">
                  Added {formatDate(artist.createdAt)}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    (window.location.href = `/artists/${artist.id}`)
                  }
                >
                  View Profile
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredArtists.length === 0 && (
        <div className="mt-8 text-center text-gray-500">
          <p>No artists found</p>
        </div>
      )}
    </div>
  );
};

export default ArtistsList;
