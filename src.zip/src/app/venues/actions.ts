// actions/venue.ts
'use server';

import { revalidatePath } from 'next/cache';
import { prisma } from '@/lib/prisma';

// types.ts
export interface VenueFormData {
  title: string;
  description: string;
  address: string;
  lat?: number;
  long?: number;
}

export async function getVenuesAction(page: number = 1, limit: number = 9) {
  try {
    const skip = (page - 1) * limit;

    const [venues, total] = await Promise.all([
      prisma.venue.findMany({
        skip,
        take: limit,
        include: {
          venueImages: true,
        },
        orderBy: {
          createdAt: 'desc',
        },
      }),
      prisma.venue.count(),
    ]);

    return {
      venues,
      total,
      page,
      totalPages: Math.ceil(total / limit),
    };
  } catch (error) {
    console.error('Failed to fetch venues:', error);
    throw new Error('Failed to fetch venues');
  }
}

export async function createVenue(data: VenueFormData, images: string[]) {
  try {
    const venue = await prisma.venue.create({
      data: {
        title: data.title,
        description: data.description,
        address: data.address,
        lat: data.lat || null,
        long: data.long || null,
        venueImages: {
          create: images.map((imageUrl) => ({
            alt: `Image for ${data.title}`,
            imageUrl,
          })),
        },
      },
    });

    revalidatePath('/venues');
    return { success: true, data: venue };
  } catch (error) {
    console.error('Failed to create venue:', error);
    return { success: false, error: 'Failed to create venue' };
  }
}

// lib/uploadImage.ts
export async function uploadImage(file: File): Promise<string> {
  // 실제 이미지 업로드 로직 구현 필요
  // 여기서는 예시로 더미 URL을 반환
  return `/images/${file.name}`;
}
