// components/VenueRegistrationForm.tsx
'use client';

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { MapPin, Upload } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { createVenue, uploadImage, VenueFormData } from '@/app/venues/actions';

const venueFormSchema = z.object({
  title: z.string().min(1, 'Venue name is required'),
  description: z.string().min(1, 'Description is required'),
  address: z.string().min(1, 'Address is required'),
  lat: z.string().optional(),
  long: z.string().optional(),
});

type VenueFormSchema = z.infer<typeof venueFormSchema>;

const Page = () => {
  const [images, setImages] = useState<File[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string>('');

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<VenueFormSchema>({
    resolver: zodResolver(venueFormSchema),
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      setImages((prevImages) => [...prevImages, ...files]);
    }
  };

  const onSubmit = async (data: VenueFormSchema) => {
    try {
      setIsSubmitting(true);
      setError('');

      // Upload all images first
      const uploadPromises = images.map(uploadImage);
      const uploadedImageUrls = await Promise.all(uploadPromises);

      // Prepare venue data
      const venueData: VenueFormData = {
        title: data.title,
        description: data.description,
        address: data.address,
        lat: data.lat ? parseFloat(data.lat) : undefined,
        long: data.long ? parseFloat(data.long) : undefined,
      };

      // Create venue with server action
      const result = await createVenue(venueData, uploadedImageUrls);

      if (!result.success) {
        throw new Error(result.error);
      }

      reset();
      setImages([]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to register venue');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl p-4">
      <Card>
        <CardHeader>
          <CardTitle>Register New Venue</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">Venue Name</Label>
              <Input
                id="title"
                {...register('title')}
                placeholder="Enter venue name"
              />
              {errors.title && (
                <span className="text-sm text-red-500">
                  {errors.title.message}
                </span>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                {...register('description')}
                placeholder="Enter venue description"
                rows={4}
              />
              {errors.description && (
                <span className="text-sm text-red-500">
                  {errors.description.message}
                </span>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <div className="flex gap-2">
                <Input
                  id="address"
                  {...register('address')}
                  placeholder="Enter venue address"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => {
                    /* Implement map selection */
                  }}
                >
                  <MapPin className="h-4 w-4" />
                </Button>
              </div>
              {errors.address && (
                <span className="text-sm text-red-500">
                  {errors.address.message}
                </span>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="lat">Latitude</Label>
                <Input
                  id="lat"
                  type="number"
                  step="any"
                  {...register('lat')}
                  placeholder="Latitude"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="long">Longitude</Label>
                <Input
                  id="long"
                  type="number"
                  step="any"
                  {...register('long')}
                  placeholder="Longitude"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Venue Images</Label>
              <div className="rounded-lg border-2 border-dashed border-gray-300 p-6 text-center">
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="image-upload"
                />
                <label
                  htmlFor="image-upload"
                  className="flex cursor-pointer flex-col items-center gap-2"
                >
                  <Upload className="h-8 w-8 text-gray-400" />
                  <span className="text-sm text-gray-500">
                    Click to upload venue images
                  </span>
                </label>
              </div>
              {images.length > 0 && (
                <div className="mt-2 grid grid-cols-3 gap-2">
                  {images.map((image, index) => (
                    <div key={index} className="relative">
                      <img
                        src={URL.createObjectURL(image)}
                        alt={`Venue image ${index + 1}`}
                        className="h-24 w-full rounded object-cover"
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? 'Registering...' : 'Register Venue'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default Page;
