'use client';
// app/venues/components/VenueList.tsx
import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { useRouter } from 'next/navigation';
import { MapPin } from 'lucide-react';

import Image from 'next/image';
import Link from 'next/link';
import { Pagination } from '@/app/venues/pagination';
import { Venue, VenueImage } from '@prisma/client';
import { getVenuesAction } from '@/app/venues/actions';

interface VenueWithImages extends Venue {
  venueImages: VenueImage[];
}

interface VenueListData {
  venues: VenueWithImages[];
  total: number;
  page: number;
  totalPages: number;
}

interface VenueListProps {
  initialData: VenueListData;
  currentPage: number;
}

export default function VenueList({
  initialData,
  currentPage,
}: VenueListProps) {
  const [data, setData] = useState<VenueListData>(initialData);
  const router = useRouter();

  useEffect(() => {
    const loadData = async () => {
      const newData = await getVenuesAction(currentPage);
      setData(newData);
    };
    loadData();
  }, [currentPage]);

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        {data.venues.map((venue) => (
          <Link href={`/venues/${venue.id}`} key={venue.id}>
            <Card className="transition-shadow hover:shadow-lg">
              <CardContent className="p-0">
                {venue.venueImages?.[0] ? (
                  <div className="relative h-48 w-full">
                    <Image
                      src={venue.venueImages[0].imageUrl}
                      alt={venue.venueImages[0].alt}
                      layout="fill"
                      objectFit="cover"
                      className="rounded-t-lg"
                    />
                  </div>
                ) : (
                  <div className="flex h-48 items-center justify-center rounded-t-lg bg-gray-200">
                    <span className="text-gray-400">No image</span>
                  </div>
                )}
                <div className="p-4">
                  <h2 className="mb-2 text-xl font-semibold">{venue.title}</h2>
                  <p className="mb-4 line-clamp-2 text-gray-600">
                    {venue.description}
                  </p>
                  <div className="flex items-center text-gray-500">
                    <MapPin className="mr-2 h-4 w-4" />
                    <span className="text-sm">{venue.address}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <Pagination
        currentPage={data.page}
        totalPages={data.totalPages}
        pageChangeAction={async (page: number) => {
          router.push(`/venues?page=${page}`);
        }}
      />
    </div>
  );
}
