// app/artworks/page.tsx
import { Suspense } from 'react';

import { Button } from '@/components/ui/button';
import Link from 'next/link';

import { getArtworks } from '@/app/artworks/actions';

import Pagination from '@/components/pagination';
import ArtworkGrid from '@/components/artwork-grid';

interface ArtworksPageProps {
  searchParams: { page?: string };
}

const Page = async ({ searchParams }: ArtworksPageProps) => {
  const currentPage = Number(searchParams.page) || 1;
  const { artworks, pagination } = await getArtworks(currentPage);
  return (
    <div className="container mx-auto py-10">
      <div className="mb-8 flex items-center justify-between">
        <h1 className="text-3xl font-bold">작품 목록</h1>
        <Link href="/artworks/create">
          <Button>새 작품 등록</Button>
        </Link>
      </div>

      <Suspense fallback={<div>작품 목록을 불러오는 중...</div>}>
        <ArtworkGrid artworks={artworks} />
      </Suspense>

      <div className="mt-8">
        <Pagination {...pagination} />
      </div>
    </div>
  );
};

export default Page;
