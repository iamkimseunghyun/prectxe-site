// app/_actions/artwork.ts
'use server';

import { prisma } from '@/lib/prisma';
import * as z from 'zod';
import { revalidatePath } from 'next/cache';

const artworkSchema = z.object({
  title: z.string().min(2).max(100),
  size: z.string().min(1),
  media: z.string().min(1),
  year: z.number().min(1900).max(new Date().getFullYear()),
  description: z.string().min(10).max(1000),
  style: z.string().min(1),
  images: z
    .array(
      z.object({
        imageUrl: z.string().url(),
        alt: z.string().min(1),
      })
    )
    .min(1),
});

export type CreateArtworkInput = z.infer<typeof artworkSchema>;

export async function createArtwork(input: CreateArtworkInput) {
  try {
    // Validate input
    const validatedData = artworkSchema.parse(input);

    // Create artwork with Prisma
    const artwork = await prisma.artwork.create({
      data: {
        title: validatedData.title,
        size: validatedData.size,
        media: validatedData.media,
        year: validatedData.year,
        description: validatedData.description,
        style: validatedData.style,
        artworkImages: {
          create: validatedData.images.map((image) => ({
            imageUrl: image.imageUrl,
            alt: image.alt,
          })),
        },
      },
      include: {
        artworkImages: true,
      },
    });

    // Revalidate the artworks page
    revalidatePath('/artworks');

    return { success: true, data: artwork };
  } catch (error) {
    if (error instanceof z.ZodError) {
      return {
        success: false,
        error: '입력값 검증에 실패했습니다.',
        details: error.errors,
      };
    }

    console.error('작품 등록 에러:', error);
    return {
      success: false,
      error: '작품 등록에 실패했습니다.',
    };
  }
}
