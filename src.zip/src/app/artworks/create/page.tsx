// app/artwork/create/page.tsx
'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useRouter } from 'next/navigation';
import { createArtwork } from '@/app/artworks/create/actions';

// Zod schema for form validation
const artworkFormSchema = z.object({
  title: z
    .string()
    .min(2, { message: '제목은 최소 2자 이상이어야 합니다.' })
    .max(100, { message: '제목은 최대 100자까지 가능합니다.' }),
  size: z.string().min(1, { message: '작품 크기를 입력해주세요.' }),
  media: z.string().min(1, { message: '미디어를 입력해주세요.' }),
  year: z
    .number()
    .min(1900, { message: '1900년 이후의 연도를 입력해주세요.' })
    .max(new Date().getFullYear(), {
      message: '현재 연도까지만 입력 가능합니다.',
    }),
  description: z
    .string()
    .min(10, { message: '설명은 최소 10자 이상이어야 합니다.' })
    .max(1000, { message: '설명은 최대 1000자까지 가능합니다.' }),
  style: z.string().min(1, { message: '작품 스타일을 선택해주세요.' }),
  images: z
    .array(
      z.object({
        imageUrl: z
          .string()
          .url({ message: '올바른 이미지 URL을 입력해주세요.' }),
        alt: z.string().min(1, { message: '이미지 설명을 입력해주세요.' }),
      })
    )
    .min(1, { message: '최소 1개의 이미지가 필요합니다.' }),
});

type ArtworkFormValues = z.infer<typeof artworkFormSchema>;

const artStyles = [
  '회화',
  '조각',
  '설치',
  '미디어아트',
  '사진',
  '퍼포먼스',
  '디지털아트',
  '혼합매체',
];

const Page = () => {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [images, setImages] = useState<{ imageUrl: string; alt: string }[]>([]);

  const form = useForm<ArtworkFormValues>({
    resolver: zodResolver(artworkFormSchema),
    defaultValues: {
      title: '',
      size: '',
      media: '',
      year: new Date().getFullYear(),
      description: '',
      style: '',
      images: [],
    },
  });

  const onSubmit = async (data: ArtworkFormValues) => {
    setIsSubmitting(true);
    setSubmitError(null);
    try {
      const result = await createArtwork(data);

      if (result.success) {
        router.push(`/artworks/detail/${result.data?.id}`);
        router.refresh();
      } else {
        setSubmitError(result.error || '작품 등록에 실패했습니다.');
      }
    } catch (error) {
      setSubmitError('알 수 없는 오류가 발생했습니다.');
      console.error('Error submitting artwork', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const addImage = () => {
    setImages([...images, { imageUrl: '', alt: '' }]);
  };

  const removeImage = (index: number) => {
    const newImages = [...images];
    newImages.splice(index, 1);
    setImages(newImages);
  };

  return (
    <div className="container mx-auto py-10">
      <h1 className="mb-8 text-3xl font-bold">새 작품 등록</h1>

      {submitError && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{submitError}</AlertDescription>
        </Alert>
      )}

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>작품 제목</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="size"
            render={({ field }) => (
              <FormItem>
                <FormLabel>작품 크기</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="예: 100x100cm" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="media"
            render={({ field }) => (
              <FormItem>
                <FormLabel>미디어</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="예: 캔버스에 유화" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="year"
            render={({ field }) => (
              <FormItem>
                <FormLabel>제작 연도</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    {...field}
                    onChange={(e) => field.onChange(parseInt(e.target.value))}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="style"
            render={({ field }) => (
              <FormItem>
                <FormLabel>작품 스타일</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="스타일을 선택해주세요" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {artStyles.map((style) => (
                      <SelectItem key={style} value={style}>
                        {style}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>작품 설명</FormLabel>
                <FormControl>
                  <Textarea {...field} rows={5} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">작품 이미지</h3>
              <Button type="button" onClick={addImage}>
                이미지 추가
              </Button>
            </div>

            {images.map((image, index) => (
              <div key={index} className="space-y-4 rounded-lg border p-4">
                <FormField
                  control={form.control}
                  name={`images.${index}.imageUrl`}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>이미지 URL</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name={`images.${index}.alt`}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>이미지 설명</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button
                  type="button"
                  variant="destructive"
                  onClick={() => removeImage(index)}
                >
                  이미지 삭제
                </Button>
              </div>
            ))}
          </div>

          <div className="flex justify-end space-x-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => window.history.back()}
            >
              취소
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? '등록 중...' : '작품 등록'}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default Page;
